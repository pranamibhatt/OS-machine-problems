#include "blocking_disk.H"
#include "scheduler.H"
#include "ThreadQ.H"
#include "thread.h"
extern Scheduler *SYSTEM_SCHEDULER;

static void issue_operation(DISK_OPERATION _op, unsigned long _block_no); 


BlockingDisk::BlockingDisk(DISK_ID _disk_id, unsigned int _size) :  SimpleDisk(_disk_id, _size)
{
	fifoQ = new ThreadQ(20);
}

void BlockingDisk::read(unsigned long _block_no, unsigned char * _buf)
{
	BlockingDisk::issue_operation(READ, _block_no);

	while(!SimpleDisk::is_ready())
	{
		fifoQ->Push(Thread::CurrentThread());
		SYSTEM_SCHEDULER->yield();
	}

	/* read data from port */
	int i;
	unsigned short tmpw;
	for (i = 0; i < 256; i++) 
	{
		tmpw = inportw(0x1F0);
		_buf[i*2]   = (unsigned char)tmpw;
		_buf[i*2+1] = (unsigned char)(tmpw >> 8);
	}

}

void BlockingDisk::write(unsigned long _block_no, unsigned char * _buf)
{
	BlockingDisk::issue_operation(WRITE, _block_no);

	while(!SimpleDisk::is_ready())
	{
		fifoQ->Push(Thread::CurrentThread());
		SYSTEM_SCHEDULER->yield();
	}

	/* write data to port */
	int i; 
	unsigned short tmpw;
	for (i = 0; i < 256; i++) 
	{
		tmpw = _buf[2*i] | (_buf[2*i+1] << 8);
		outportw(0x1F0, tmpw);
	}
}

Thread * BlockingDisk::getBlockedThread()
{
	return fifoQ->Pop();
}
