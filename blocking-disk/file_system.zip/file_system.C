#include "file_system.H"
#include "simple_disk.H"
#include "blocking_disk.H"
#include "types.H"
#include "utils.H"
#include "console.H"

#define INDEX_FROM_BIT(Sector) ((Sector) / (sizeof(uint32) * 8))
#define OFFSET_FROM_BIT(Sector) ((Sector) % (sizeof(uint32) * 8))

void set_Sector(uint32 * Bitmap, uint32 SectorNumber)
{
	uint32 index = INDEX_FROM_BIT(SectorNumber);
	uint32 offset = OFFSET_FROM_BIT(SectorNumber);
	Bitmap[index] |= (0x1 << offset);
}

void clear_Sector(uint32 * Bitmap, uint32 SectorNumber)
{

	uint32 index = INDEX_FROM_BIT(SectorNumber);
	uint32 offset = OFFSET_FROM_BIT(SectorNumber);
	Bitmap[index] &= ~(0x1 << offset);
}

uint32 test_Sector(uint32 * Bitmap, uint32 SectorNumber)
{
	uint32 index = INDEX_FROM_BIT(SectorNumber);
	uint32 offset = OFFSET_FROM_BIT(SectorNumber);
	return Bitmap[index] & (0x1 << offset);
}

FileSystem * File::_FileSystem = NULL;

File::File(uint32 FileId)
{
	if(FileId)
	{
		_FileId = FileId;
		_FileSize = 0;
		_StartingSector = 0;
		_CurrentSector = _StartingSector;
		_CurrentPosition = 0;
	}
}
/* Constructor for the file handle. Set the 'current
position' to be at the beginning of the file. */
unsigned int File::Read(unsigned int _n, unsigned char * _buf)
{
	// Is buf valid?
	uint32 bytesRead = 0;
	if(_buf && _n)
	{
		uint32 bytesToRead;
		uint32 bytesAvailable = _FileSize - _CurrentPosition;
		if(_n > bytesAvailable)
		{
			bytesToRead = bytesAvailable;
		}
		else
		{
			bytesToRead = _n;
		}
		while(bytesRead < bytesToRead)
		{
			BYTE	readBuffer[512];
			uint32 positionInSector = _CurrentPosition % (_FileSystem->GetSectorSize() - SectorOverhead);
			uint32 bytesToCopy = 0;
			_FileSystem->_Disk->read(_CurrentSector, readBuffer);
			// Are remaining bytes in current sector?
			if((bytesToRead - bytesRead) <= (_FileSystem->GetSectorSize() - SectorOverhead))
			{
				// What is left in sector
				bytesToCopy = bytesToRead - bytesRead;
			}
			else
			{
				// whole sector
				bytesToCopy = _FileSystem->GetSectorSize() - SectorOverhead;
			}
			// Copy data
			memcpy(&_buf[bytesRead], &readBuffer[positionInSector],  bytesToCopy);
			
			// Update counters
			bytesRead = bytesRead + bytesToCopy;
			_CurrentPosition = _CurrentPosition + bytesToCopy;
			
			// Update current sector
			if(bytesRead < bytesToRead)
			{
				memcpy(&_CurrentSector, &readBuffer[_FileSystem->GetSectorSize() - SectorOverhead], sizeof(uint32));
			}
		}
		
	}
	return bytesRead;
}



/* Read _n characters from the file starting at the current location and
copy them in _buf. Return the number of characters read. */
unsigned int File::Write(unsigned int _n, unsigned char * _buf)
{

}
/* Write _n characters to the file starting at the current location, if we
run past the end of file, we increase the size of the file as needed. */
void File::Reset()
{
	_CurrentPosition = 0;
	_CurrentSector = _StartingSector;
}
/* Set the 'current position' at the beginning of the file. */
void File::Rewrite()
{
	uint32 sector = _StartingSector;
	while(TRUE)
	{
		BYTE buf[512];
		uint32 newSector;
		
		// Read the link to the next sector
		_Disk->read(sector, buf);
		// Mark current sector as available
		clear_Sector(_SectorBitmap, sector);
		// Read link sector number
		memcpy(&newSector, &buf[508], sizeof(uint32));
		// Null out buffer
		memset(buf, 0, sizeof(buf));
		// Kill sector
		_Disk->write(sector, buf);
		// If the link was not 0, we must repeat
		if(newSector)
		{
			// Save sector index
			sector = newSector;
		}
		else
		{
			break;
		}	
	}
	_FileSize = 0;
	_CurrentPosition = 0;
	_StartingSector = 0;
	_CurrentSector = 0;
}
/* Erase the content of the file. Return any freed blocks.
Note: This function does not delete the file! It just erases its content. */
BOOLEAN File::EoF()
{
	return (_CurrentPosition == _FileSize);
}
/* Is the current location for the file at the end of the file? */

void File::SetFileSystem(FileSystem * FileSys)
{
	_FileSystem = FileSys;
}




FileSystem::FileSystem()
{
	_Disk = NULL;
     _Size = 0;
	_NumOfFiles = 0;
	memset(_SectorBitmap, 0, sizeof(_SectorBitmap));
	memset(_FilesIDs, 0, sizeof(_FilesIDs));
	memset(_FilesLengths, 0, sizeof(_FilesLengths));
	memset(_FilesStartSectors, 0, sizeof(_FilesStartSectors));
}
/* Just initializes local data structures. Does not connect to disk yet. */
BOOLEAN FileSystem::Mount(SimpleDisk * _disk)
{
	if(_disk)
	{
		BYTE buf[512];
		_Disk = _disk;
		
		/* Structure of FileSys Management Data
		BYTES
		0 - 3 : Disk Size;
		4 - 7 : Number of Files;
		8 - 47 : Files IDs
		48 - 87 : Files Lengths
		88 - 127 : Files Starting Sectors
		128 - 511 : Unused
		512 - 1023 : Sector Bitmap
		*/
		// Read in the first management data
		_Disk->read(0, buf);
		memcpy(&_Size, &buf[0], sizeof(_Size));
		memcpy(&_NumOfFiles, &buf[4], sizeof(_NumOfFiles));
		memcpy(&_FilesIDs[0], &buf[8], sizeof(_FilesIDs));
		memcpy(&_FilesLengths[0], &buf[48], sizeof(_FilesLengths));
		memcpy(&_FilesStartSectors[0], &buf[88], sizeof(_FilesStartSectors));
		
		// Read in the sector bitmap
		_Disk->read(1, buf);
		memcpy(&_SectorBitmap[0], buf, sizeof(_SectorBitmap));
		return TRUE;
	}
	return FALSE;
}
/* Associates the file system with a disk. Limit to at most one file system per disk.
Returns TRUE if operation successful (i.e. there is indeed a file system on the disk. */
BOOLEAN FileSystem::Format(SimpleDisk * _disk, unsigned int _size)
{
	BYTE buf[512];
	uint32 tempVal;
	uint32 index;
	memset(buf, 0, sizeof(buf));
	
	// Wipe whole disk
	for(index = 0; index < (_size / _disk->SectorSize); index++)
	{
		_disk->write(index, buf);	
	}
	
	/* Structure of FileSys Management Data
	BYTES
	0 - 3 : Disk Size;
	4 - 7 : Number of Files;
	8 - 47 : Files IDs
	48 - 87 : Files Lengths
	88 - 127 : Files Starting Sectors
	128 - 511 : Unused
	512 - 1023 : Sector Bitmap
	*/
	tempVal = _size;
	memcpy(&buf[0], &tempVal, 4);
	// Only size is not zer0 at this point;
	// Write all data in sector 0
	_disk->write(0, buf);
	
}
/* Wipes any file system from the given disk and installs an empty file system of given size. */
BOOLEAN FileSystem::LookupFile(int _file_id, File * _file)
{
	// Neither can be 0
	if(_file_id && _file)
	{
		uint32 index;
		//If file exists already, abort and return FALSE
		for(index = 0; index < FileSysMaxFiles; index++)
		{
			if(_FilesIDs[index] == _file_id)
			{
				_file->_FileId = _FilesIDs[index];
				_file->_FileSize = _FilesLengths[index];
				_file->_StartingSector = _FilesStartSectors[index];
				return TRUE;
			}
		}
	}
	return FALSE;
}
/* Find file with given id in file system. If found, initialize the file
object and return TRUE. Otherwise, return FALSE. */
BOOLEAN FileSystem::CreateFile(int _file_id)
{
	uint32 index;
	
	//If file exists already, abort and return FALSE
	for(index = 0; index < FileSysMaxFiles; index++)
	{
		if(_FilesIDs[index] == _file_id)
		{
			return FALSE;
		}
	}
	
	// Create file with given id in the file system
	if(_NumOfFiles < FileSysMaxFiles)
	{
		for(index = 0; index < FileSysMaxFiles; index++)
		{
			if(_FilesIDs[index] == 0)
			{
				// Spot available
				break;
			}
		}
		if(index < FileSysMaxFiles)
		{
			_FilesIDs[index] = _file_id;
			_FilesLengths[index] = 0;
			_FilesStartSectors[index] = 0;
			return TRUE;
		}
	}
	return FALSE;		
}
/* Create file with given id in the file system. If file exists already,
abort and return FALSE. Otherwise, return TRUE. */
BOOLEAN FileSystem::DeleteFile(int _file_id)
{
	// Find file
	uint32 index;
	for(index = 0; index < FileSysMaxFiles; index++)
	{
		if(_FilesIDs[index] == _file_id)
		{
			// Found it
			break;
		}
	}
	if(index < FileSysMaxFiles)
	{
		uint32 sector;
		_FilesIDs[index] = 0;
		_FilesLengths[index] = 0;
		sector = _FilesStartSectors[index];
		_FilesStartSectors[index] = 0;
		while(TRUE)
		{
			BYTE buf[512];
			uint32 newSector;
			
			// Read the link to the next sector
			_Disk->read(sector, buf);
			// Mark current sector as available
			clear_Sector(_SectorBitmap, sector);
			// Read link sector number
			memcpy(&newSector, &buf[508], sizeof(uint32));
			// Null out buffer
			memset(buf, 0, sizeof(buf));
			// Kill sector
			_Disk->write(sector, buf);
			// If the link was not 0, we must repeat
			if(newSector)
			{
				// Save sector index
				sector = newSector;
			}
			else
			{
				return TRUE;
			}	
		}
	}
	return FALSE;
}
/* Delete file with given id in the file system and free any disk block occupied by the file. */
uint32 FileSystem::GetSectorSize()
{
	if(_Disk)
	{
		return _Disk->SectorSize;
	}
	return 0;
}

uint32 FileSystem::GetFreeSector()
 {
	uint32 index;
	// First 2 sectors are off limits
	for(index = 2; index < (_Size / GetSectorSize()); index++)
	{
		if(!test_Sector(_SectorBitmap, index))
		{
			set_Sector(_SectorBitmap, index);
			return index;
		}
	}
	return 0;
 }